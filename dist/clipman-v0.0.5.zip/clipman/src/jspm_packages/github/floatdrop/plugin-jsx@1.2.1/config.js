System.config({
  "paths": {
    "*": "*.js"
  }
});


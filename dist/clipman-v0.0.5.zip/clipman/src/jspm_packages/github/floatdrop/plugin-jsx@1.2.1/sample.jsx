module.exports = function () {
	return <div id="jsx">Hello JSX!!</div>;
};

/* */ 
module.exports = System._nodeRequire ? System._nodeRequire('zlib') : require('browserify-zlib');
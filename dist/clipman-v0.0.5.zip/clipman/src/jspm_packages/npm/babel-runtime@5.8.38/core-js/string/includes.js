/* */ 
module.exports = { "default": require("core-js/library/fn/string/includes"), __esModule: true };
/* */ 
module.exports = System._nodeRequire ? System._nodeRequire('https') : require('https-browserify');
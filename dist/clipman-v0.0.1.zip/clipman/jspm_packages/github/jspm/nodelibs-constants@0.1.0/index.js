/* */ 
module.exports = System._nodeRequire ? System._nodeRequire('constants') : require('constants-browserify');
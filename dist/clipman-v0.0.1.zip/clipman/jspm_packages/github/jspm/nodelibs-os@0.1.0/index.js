/* */ 
module.exports = System._nodeRequire ? System._nodeRequire('os') : require('os-browserify');
/* */ 
if (System._nodeRequire)
  module.exports = System._nodeRequire('child_process');
else
  throw "Node child_process module not supported in browsers.";
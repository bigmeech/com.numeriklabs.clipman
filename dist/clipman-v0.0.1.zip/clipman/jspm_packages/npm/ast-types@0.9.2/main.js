/* */ 
module.exports = require('./fork')([require('./def/core'), require('./def/es6'), require('./def/es7'), require('./def/mozilla'), require('./def/e4x'), require('./def/jsx'), require('./def/flow'), require('./def/esprima'), require('./def/babel'), require('./def/babel6')]);

/* */ 
"format cjs";
export function isDummy(node) { return node.name == "✖" }
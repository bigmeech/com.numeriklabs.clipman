/* */ 
module.exports = { "default": require("core-js/library/fn/array/find"), __esModule: true };
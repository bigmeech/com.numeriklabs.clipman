/* */ 
module.exports = { "default": require("core-js/library/fn/reflect/is-extensible"), __esModule: true };
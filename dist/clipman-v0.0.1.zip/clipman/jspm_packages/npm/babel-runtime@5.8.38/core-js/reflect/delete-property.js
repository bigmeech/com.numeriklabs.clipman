/* */ 
module.exports = { "default": require("core-js/library/fn/reflect/delete-property"), __esModule: true };
/* */ 
module.exports = { "default": require("core-js/library/fn/string/at"), __esModule: true };
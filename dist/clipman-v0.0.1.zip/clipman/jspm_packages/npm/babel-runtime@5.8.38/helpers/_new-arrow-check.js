/* */ 
module.exports = require('./newArrowCheck');

import './components/app.jsx!';

console.log('this is just a test');
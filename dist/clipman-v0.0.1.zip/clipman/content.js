import AppComponent from './components/app/app.jsx!'
import ReactDom from 'react-dom'
import React from 'react'

ReactDom.render(
    React.createElement(AppComponent),
    document.body);
import './components/app/app.jsx!';

console.log('this is just a test');
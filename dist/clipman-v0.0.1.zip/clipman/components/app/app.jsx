/** @jsx React.DOM */

import React from 'React';

export default class App extends React.Component {
  render(){
    return <div>This is a sample component</div>
  }
}
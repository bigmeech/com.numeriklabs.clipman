import React from 'react';

const App =  React.createClass({
  render: function(){
    return (
        <div>Main App Lol!</div>
    );
  }
});


export default App;
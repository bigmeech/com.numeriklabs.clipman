/** @jsx React.DOM */

import React from 'react';

export default class App extends React.Component {
  render(){
    return <div>This is a sample component</div>
  }
}
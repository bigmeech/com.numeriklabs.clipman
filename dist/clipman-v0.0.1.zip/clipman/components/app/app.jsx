/** @jsx React.DOM */

import React from 'React';

class App extends React.Component {
  render(){
    return <Dialog></Dialog>
  }
}